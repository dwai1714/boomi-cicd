import base64
import toml
import os


def generate_base64_credentials(username, password):
    credentials = f"{username}:{password}"
    base64_credentials = base64.b64encode(credentials.encode()).decode()
    return base64_credentials

# Replace 'your_username' and 'your_password' with your actual credentials
username = 'prasanna.s@accionlabs.com'
password = 'Pras13Shaan@16'

# Get the script's directory
script_dir = os.path.dirname(os.path.abspath(__file__))

# Generate Base64-encoded credentials
base64_credentials = generate_base64_credentials(username, password)

# Load the existing config file
config_file_path = os.path.join(script_dir, 'config.toml')
with open(config_file_path, 'r') as file:
    config = toml.load(file)

# Update the DEV section with the new credentials
config['DEV']['base64_credentials'] = base64_credentials

# Save the updated config file
with open(config_file_path, 'w') as file:
    toml.dump(config, file)
