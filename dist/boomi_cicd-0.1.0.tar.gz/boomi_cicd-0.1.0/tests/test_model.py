from unittest.mock import patch, Mock

from cicd.resources.model import Model


def test_create_model(self):
    # Arrange
    model_name = 'test_model'
    config_file_path = 'test_config.toml'
    file_name = 'path/to/xml/file'
    repository_name = 'test_repo'
    account_id = 'test_account'
    cloud_id = 'test_cloud'
    base64_credentials = 'test_credentials'
    endpoint_url = 'https://test.com'
    model = Model(model_name, config_file_path, file_name, repository_name, account_id, cloud_id, base64_credentials, endpoint_url)

    # Act and Assert
    with patch('requests.post') as mock_post:
        # Negative Scenario 1: Invalid XML file
        mock_post.return_value = Mock(status_code=400), Mock(content='Bad Request')
        with self.assertRaises(ValueError) as context:
            model.create_model()
        self.assertEqual(context.exception.args[0], 'XML File is malformed')

        # Negative Scenario 2: Invalid endpoint URL
        mock_post.reset_mock()
        mock_post.return_value = Mock(status_code=400), Mock(content='Bad Request')
        with self.assertRaises(RuntimeError) as context:
            model.create_model()
        self.assertEqual(context.exception.args[0], 'Response is not 200. Exiting')

        # Negative Scenario 3: Model name mismatch
        mock_post.reset_mock()
        mock_post.return_value = Mock(status_code=200), Mock(content='Success')
        with self.assertRaises(ValueError) as context:
            model = Model('test_model_2', config_file_path, file_name, repository_name, account_id, cloud_id, base64_credentials, endpoint_url)
            model.create_model()
        self.assertEqual(context.exception.args[0], 'model names in file and object are different')

        # Negative Scenario 4: Model exists
        mock_post.reset_mock()
        mock_post.return_value = Mock(status_code=200), Mock(content='Success')
        with self.assertRaises(ValueError) as context:
            model = Model(model_name, config_file_path, file_name, repository_name, account_id, cloud_id, base64_credentials, endpoint_url)
            model.create_model()
        self.assertEqual(context.exception.args[0], 'model with same name exists')